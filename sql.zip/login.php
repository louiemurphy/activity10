<?php
$errorCode = $_GET["error"];

$fusername = $_POST["username"];
$pass = $_POST["password"];

$servername = "localhost";
$username = "root";
$password = "";
$dbName = "accountsDb";

// Function for basic field validation (present and neither empty nor only white space
function IsNullOrEmptyString($str)
{
    return ($str === null || trim($str) === '');
}

// create connection
$conn = new mysqli($servername, $username, $password, $dbName);
if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}
// attempt login
if (isset($_POST["username"]))
{
    $success = false;
    $sql = "SELECT * FROM accountsTb WHERE username='" . $fusername  . "' AND pass='" . $pass . "'";
    if ($result = $conn->query($sql))
    {
        while ($row = $result->fetch_row())
        {
            $success = true;
        }
    }
    if ($success)
    {
      setcookie("name", $fusername );
      setcookie("pass", $pass  );
      header("location: ./homepage.php");
    }
    else
    {
      $errorCode = 1;
    }
}
?>
<html>
    <head>
        <link rel="icon"  href="favicon.ico?v=2"/>
        <title>Login</title>
        <!-- JavaScript Bundle with Popper -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    </head>
 
 <body>
 
     <div class="container mt-4">
      <?php if ($errorCode == 1): ?>
        <div class="alert alert-danger" role="alert">
          Bad username or password!
        </div>
      <?php endif; ?>
        <form action="login.php" method="post">
            <h2>Login</h2>
             <div class="form-text">Please login with your username and password.</div>
            <div class="mb-3 mt-2">
              <label for="Username" class="form-label">Username</label>
              <input type="text" class="form-control" id="username" aria-describedby="username" name="username">
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" class="form-control" id="password" name="password">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            <a type="btn" class="btn btn-secondary" href="./register.html">Register</a>
          </form>
     </div>
 </body>
</html>
