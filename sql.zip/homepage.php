<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbName = "accountsDb";

    $toEdit = $_POST["edit"];

    // Function for basic field validation (present and neither empty nor only white space
    function IsNullOrEmptyString($str)
    {
        return ($str === null || trim($str) === '');
    }

    

    // create connection
    $conn = new mysqli($servername, $username, $password, $dbName);
    if ($conn->connect_error)
    {
        die("Connection failed: " . $conn->connect_error);
    }
    // attempt login

    $success = false;
    $sql = "SELECT * FROM accountsTb WHERE username='" . $_COOKIE["name"]  . "' AND pass='" . $_COOKIE["pass"] . "'";
    if ($result = $conn->query($sql))
    {
        while ($row = $result->fetch_row())
        {
            $success = true;
        }
    }
    
    if ($success)
    {

    }
    else
    {
        header("location: ./login.php?error=1");
    }
    // edit if needed
    if ($toEdit == 1)
    {
        $sql = "UPDATE accountsTb SET email='" . $_POST["email"] . "', pass='" . $_POST["password"] . "', username='" . $_POST["username"] . "' WHERE id=" . $_POST["editIndex"] . " ";
        if ($conn->query($sql) === TRUE) {

        } else {
          echo "Error updating record: " . $conn->error . $sql;
        }
    }


    //get results from database
    $result = mysqli_query($conn, "SELECT * FROM accountsTb");
    $all_property = array();  //declare an array for saving property

?>
<html>
    <head>
        <link rel="icon"  href="favicon.ico?v=2"/>
        <title>Home Page</title>
        <!-- JavaScript Bundle with Popper -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    </head>
 
 <body>
     <div class="container mt-4">
        <h2>Edit Users</h2>
<?php
    // show the entire table
    echo '<table class="data-table table">
            <tr class="data-heading">';  //initialize table tag
    while ($property = mysqli_fetch_field($result)) {
        echo '<td>' . $property->name . '</td>';  //get field name for header
        $all_property[] = $property->name;  //save those to array
    }
    echo '<td>action</td>';  //get field name for header
    echo '</tr>'; //end tr tag

    //showing all data
    while ($row = mysqli_fetch_array($result)) {
        $params = "";
        echo "<tr>";
        foreach ($all_property as $item) {
            echo '<td>' . $row[$item] . '</td>'; //get items using property value
            $params = "'" . $row[$item]  . "'," . $params ;
        }
        echo '<td><button onclick="showEdit(' . $params . ')" type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editModal">Edit</button></td>';  //get field name for header
        echo '</tr>';
    }
    echo "</table>";
?>
</div>

<script>
    function showEdit(username, pass, email, id)
    {
        document.getElementById("editEmail").value = email;
        document.getElementById("editPassword").value = pass;
        document.getElementById("editName").value = username;
        document.getElementById("editIndex").value = id;
    }
</script>

<!-- Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="./homepage.php" method="post">
      <div class="modal-header">
        <h5 class="modal-title" id="label">Edit Item</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input id="editEmail" type="email" name="email" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Password</label>
            <input id="editPassword" type="password" name="password" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Username</label>
            <input id="editName" type="username" name="username" class="form-control">
        </div>
            <input id="editIndex" type="hidden" name="editIndex" value="1" class="form-control">
            <input id="edit" type="hidden" name="edit" value="1" class="form-control">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Submit</button>
      </div>
        </form>
    </div>
  </div>
</div>

 </body>
</html>