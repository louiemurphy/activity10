<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbName = "accountsDb";

    $email = $_POST["email"];
    $pass = $_POST["password"];
    $fusername = $_POST["username"];

    // create connection
    $conn = new mysqli($servername, $username, $password);
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // php connected
    $sql = "CREATE DATABASE IF NOT EXISTS " . $dbName ;
    if ($conn->query($sql) !== TRUE) {
        die("Error creating database.");
    }   
    $conn -> select_db($dbName);

    // create the table
    $sql = "CREATE TABLE IF NOT EXISTS accountsTb(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, email VARCHAR(50) NOT NULL, pass VARCHAR(50) NOT NULL, username VARCHAR(50))";
    if ($conn->query($sql) !== TRUE) {
        echo "Unable to create table.";
        die(mysqli_error($sql));
    } 

    // insert account
    $sql = "INSERT INTO accountsTb(email, pass, username) VALUES('" . $email  . "', '" .  $pass . "', '" . $fusername  . "')";
        if ($conn->query($sql) !== TRUE) {
            echo "Unable to insert data.";
            die(mysqli_error($sql));
        } 


?>
<html>
    <head>
        <link rel="icon"  href="favicon.ico?v=2"/>
        <title>Registered Successfully!</title>
        <!-- JavaScript Bundle with Popper -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    </head>
 
 <body>
     <div class="container mt-4">
            <h2>Register Success!</h2> 
            Registered as <?php echo $email;?>
            <a href="login.php">Click here to Login</a>
     </div>
 </body>
</html>